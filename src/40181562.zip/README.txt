The 'tv_show.txt' file must be within the 'src' folder of the project.

To edit or remove a TV series, administrator mode must be activated. 
To do this go to the main menu then the 'Activate administrator mode' option (option 4). 
The password is: Admin16

To save any changes made in the application, ensure that you exit by using the 'Exit application' option in the main menu.